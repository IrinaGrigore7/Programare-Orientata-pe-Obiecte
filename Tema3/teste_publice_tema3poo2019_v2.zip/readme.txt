Prima cerinta:
in: echipe1.in, echipe4.in
out: inscriere1.out, inscriere4.out

A doua cerinta:
in1: echipe6.in, echipe8.in, echipe10.in, echipe11.in, echipe13.in, echipe14.in, echipe16.in
in2: competitie6.in, competitie8.in, competitie10.in, competitie11.in, competitie13.in, competitie14.in, competitie16.in
out: rezultate6.in, rezultate8.in, rezultate10.in, rezultate11.in, rezultate13.in, rezultate14.in, rezultate16.in